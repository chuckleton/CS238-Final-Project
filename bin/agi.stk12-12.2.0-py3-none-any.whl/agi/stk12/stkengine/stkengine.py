################################################################################
#          Copyright 2020-2020, Analytical Graphics, Inc.
################################################################################

__all__ = ['STKEngine', 'STKEngineApplication']

import os

from ctypes import byref
if os.name != 'nt':
    from ctypes import CFUNCTYPE, cdll, c_size_t, c_int, c_void_p

from agi.stk12.internal.comutil            import CLSCTX_INPROC_SERVER, COINIT_APARTMENTTHREADED, GUID
from agi.stk12.internal.comutil            import CLSIDFromString, CoCreateInstance, CoInitializeManager, IUnknown, ObjectLifetimeManager, Succeeded
from agi.stk12.internal.stkxinitialization import *
from agi.stk12.utilities.exceptions        import *
from agi.stk12.graphics                    import *
from agi.stk12.stkobjects                  import *
from agi.stk12.stkobjects.astrogator       import *
from agi.stk12.stkobjects.aviator          import *
from agi.stk12.stkutil                     import *
from agi.stk12.stkx                        import *
from agi.stk12.vgt                         import *

class STKEngineApplication(AgSTKXApplication):
    '''
    Interact with STK Engine.  Use STKEngine.StartApplication() to obtain an initialized STKEngineApplication object.
    '''
    def __init__(self):
        AgSTKXApplication.__init__(self)
        self.__dict__['_stk_install_dir'] = None
        self.__dict__['_stk_config_dir'] = None
        self.__dict__['_initialized'] = False

    def _private_init(self, pUnk:IUnknown, stk_install_dir=None, stk_config_dir=None):
        AgSTKXApplication._private_init(self, pUnk)
        self.__dict__['_stk_install_dir'] = stk_install_dir
        self.__dict__['_stk_config_dir'] = stk_config_dir
        self._STKXInitialize()
        self._STKXInitializeTimer()
        self.__dict__['_initialized'] = True
        
    def __del__(self):
        ObjectLifetimeManager.ReleaseAll(releaseApplication=True)
        if self.__dict__['_initialized']:
            CoInitializeManager.uninitialize()
        
    def _STKXInitialize(self):
        if os.name=='nt':
            return
        CLSID_AgSTKXInitialize = GUID()
        if Succeeded(CLSIDFromString('{3B85901D-FC82-4733-97E6-5BB25CE69379}', CLSID_AgSTKXInitialize)):
            IID_IUnknown = GUID(IUnknown._guid)
            stkxinit_unk = IUnknown()
            if Succeeded(CoCreateInstance(byref(CLSID_AgSTKXInitialize), None, CLSCTX_INPROC_SERVER, byref(IID_IUnknown), byref(stkxinit_unk.p))):
                stkxinit_unk.TakeOwnership()
                pInit = IAgSTKXInitialize()
                pInit._private_init(stkxinit_unk)
                install_dir = self.__dict__['_stk_install_dir'] if self.__dict__['_stk_install_dir'] is not None else os.getenv('STK_INSTALL_DIR')
                if install_dir is None:
                    raise STKInitializationError('Please set a valid STK_INSTALL_DIR environment variable.')
                config_dir = self.__dict__['_stk_config_dir'] if self.__dict__['_stk_config_dir'] is not None else os.getenv('STK_CONFIG_DIR')
                if config_dir is None:
                    raise STKInitializationError('Please set a valid STK_CONFIG_DIR environment variable.')
                pInit.InitializeData(install_dir, config_dir)
                
    @staticmethod
    def _defaultTimerProc(id):
        pass
        
    @staticmethod
    def _defaultInstallTimer(iSeconds, TIMERPROC, callbackData):
        return 1
        
    @staticmethod
    def _defaultDeleteTimer(timerID, callbackData):
        return 0
                
    def _STKXInitializeTimer(self):
        if os.name=='nt':
            return
        agutillib = cdll.LoadLibrary("libagutil.so")
        TIMERPROC = CFUNCTYPE(None, c_size_t)
        INSTALLTIMER = CFUNCTYPE(c_size_t, c_int, TIMERPROC, c_void_p)
        DELETETIMER = CFUNCTYPE(c_int, c_size_t, c_void_p)
        AgUtSetTimerCallbacks = CFUNCTYPE(None, INSTALLTIMER, DELETETIMER, c_void_p)(("AgUtSetTimerCallbacks", agutillib), ((1, "pInstallTimer"), (1, "pDeleteTimer"), (1, "pCallbackData")))
        AgUtInstallTimer = CFUNCTYPE(c_size_t, c_int, TIMERPROC)(("AgUtInstallTimer", agutillib), ((1, "iSeconds"), (1, "timerProc")))
        self.__dict__['_install_timer'] = INSTALLTIMER(STKEngineApplication._defaultInstallTimer)
        self.__dict__['_delete_timer'] = DELETETIMER(STKEngineApplication._defaultDeleteTimer)
        self.__dict__['_timerproc'] = TIMERPROC(STKEngineApplication._defaultTimerProc)
        AgUtSetTimerCallbacks(self._install_timer, self._delete_timer, c_void_p())
        timerID = AgUtInstallTimer(100, self._timerproc)
        
    def NewObjectRoot(self) -> AgStkObjectRoot:
        '''
        Create a new object model root for the STK Engine application.
        '''
        if not self.__dict__['_initialized']:
            raise RuntimeError('STKEngineApplication has not been properly initialized.  Use start_stkengine() to obtain the STKEngineApplication object.')
        CLSID_AgStkObjectRoot = GUID()
        if Succeeded(CLSIDFromString('{96C1CE4E-C61D-4657-99CB-8581E12693FE}', CLSID_AgStkObjectRoot)):
            IID_IUnknown = GUID(IUnknown._guid)
            root_unk = IUnknown()
            CoCreateInstance(byref(CLSID_AgStkObjectRoot), None, CLSCTX_INPROC_SERVER, byref(IID_IUnknown), byref(root_unk.p))
            root_unk.TakeOwnership()
            root = AgStkObjectRoot()
            root._private_init(root_unk)
            return root

    def ShutDown(self) -> None:
        '''
        Shut down the STK Engine application.
        '''
        if self.__dict__['_initialized']:
            ObjectLifetimeManager.ReleaseAll(releaseApplication=False)
            self.Terminate()


class STKEngine(object):
    '''
    Initialize and manage the STK Engine application.
    '''
    _is_engine_running = False
    _stk_config_dir = None
    _stk_install_dir = None
            
    @staticmethod
    def StartApplication(noGraphics:bool = True) -> STKEngineApplication:
        '''
        Initialize STK Engine in-process and return the instance.  Must only be used once per Python process.
        '''
        if STKEngine._is_engine_running:
            raise RuntimeError('Only one STKEngine instance is allowed per Python process.')
        CoInitializeManager.initialize()
        CLSID_AgSTKXApplication = GUID()
        if Succeeded(CLSIDFromString('{062AB565-B121-45B5-A9A9-B412CEFAB6A9}', CLSID_AgSTKXApplication)):
            pUnk = IUnknown()
            IID_IUnknown = GUID(IUnknown._guid)
            if Succeeded(CoCreateInstance(byref(CLSID_AgSTKXApplication), None, CLSCTX_INPROC_SERVER, byref(IID_IUnknown), byref(pUnk.p))):
                pUnk.TakeOwnership(isApplication=True)
                STKEngine._is_engine_running = True
                engine = STKEngineApplication()
                engine._private_init(pUnk, STKEngine._stk_install_dir, STKEngine._stk_config_dir)
                engine.NoGraphics = noGraphics
                return engine
        raise STKInitializationError("Failed to create STK Engine application.  Check for successful install and registration.")
                
    if os.name != 'nt':
        @staticmethod
        def SetSTKInstallDir(stkInstallDir:str) -> None:
            '''
            Setting the install directory using this method will override the STK_INSTALL_DIR environment variable.
            If this method is not called, STK_INSTALL_DIR will be used instead.  This method must be called before
            StartApplication().
            '''
            STKEngine._stk_install_dir = stkInstallDir
            
        @staticmethod
        def SetSTKConfigDir(stkConfigDir:str) -> None:
            '''
            Setting the config directory using this method will override the STK_CONFIG_DIR environment variable.
            If this method is not called, STK_CONFIG_DIR will be used instead.  This method must be called before
            StartApplication().
            '''
            STKEngine._stk_config_dir = stkConfigDir
        
       


################################################################################
#          Copyright 2020-2020, Analytical Graphics, Inc.
################################################################################
