################################################################################
#          Copyright 2021-2021, Analytical Graphics, Inc.
################################################################################

__all__ = ['GlobeControl', 'MapControl', 'GfxAnalysisControl']

import os
from tkinter                    import Frame
from ctypes                     import *

from agi.stk12.stkx             import IAgUiAxVOCntrl, IAgUiAx2DCntrl, IAgUiAxGfxAnalysisCntrl
from agi.stk12.internal.comutil import IUnknown, INT, LONG, LPVOID, LPCWSTR, DWORD
from agi.stk12.stkengine        import *

if os.name != "nt":
    from ctypes import CFUNCTYPE
    WINFUNCTYPE=CFUNCTYPE

class NativeContainerMethods:
    def __init__(self):
        self.jniCore = CDLL(self._getJNICorePath())
        self.Java_agi_core_awt_AgAwtNativeContainer_CreateContainer_Python   = WINFUNCTYPE(LPVOID, LPVOID, LPVOID, LPCWSTR)(("Java_agi_core_awt_AgAwtNativeContainer_CreateContainer_Python", self.jniCore), ((1, "env"), (1, "_this"), (1, "progId")))
        self.Java_agi_core_awt_AgAwtNativeContainer_AttachContainer          = WINFUNCTYPE(LPVOID, LPVOID, LPVOID, LPVOID, LPVOID, LPVOID)(("Java_agi_core_awt_AgAwtNativeContainer_AttachContainer", self.jniCore), ((1, "env"), (1, "_this"), (1, "pNativeCanvas"), (1, "pNativeDisplay"), (1, "pContainer")))
        self.Java_agi_core_awt_AgAwtNativeContainer_ResizeContainer          = WINFUNCTYPE(LPVOID, LPVOID, LPVOID, LPVOID, LONG, LONG, LONG, LONG)(("Java_agi_core_awt_AgAwtNativeContainer_ResizeContainer", self.jniCore), ((1, "env"), (1, "_this"), (1, "pContainer"), (1, "x"), (1, "y"), (1, "width"), (1, "height")))
        self.Java_agi_core_awt_AgAwtNativeContainer_Paint                    = WINFUNCTYPE(LPVOID, LPVOID, LPVOID, LPVOID)(("Java_agi_core_awt_AgAwtNativeContainer_Paint", self.jniCore), ((1, "env"), (1, "_this"), (1, "pContainer")))
        self.Java_agi_core_awt_AgAwtNativeContainer_GetIAgUnknown_Python     = WINFUNCTYPE(LPVOID, LPVOID, LPVOID, LPVOID)(("Java_agi_core_awt_AgAwtNativeContainer_GetIAgUnknown_Python", self.jniCore), ((1, "env"), (1, "_this"), (1, "pContainer")))
        self.Java_agi_core_awt_AgAwtNativeContainer_DetachContainer          = WINFUNCTYPE(LPVOID, LPVOID, LPVOID, LPVOID)(("Java_agi_core_awt_AgAwtNativeContainer_DetachContainer", self.jniCore), ((1, "env"), (1, "_this"), (1, "pContainer")))
        self.Java_agi_core_awt_AgAwtNativeContainer_ReleaseContainer         = WINFUNCTYPE(LPVOID, LPVOID, LPVOID, LPVOID)(("Java_agi_core_awt_AgAwtNativeContainer_ReleaseContainer", self.jniCore), ((1, "env"), (1, "_this"), (1, "pContainer")))
    def _getJNICorePath(self):
        if not STKEngine._is_engine_running:
            raise STKRuntimeError(f"STKEngine.StartApplication() must be called before using the STK Engine controls")
            
        if os.name != 'nt':
            return 'libagjnicore.so'
        else:
            kernel32 = WinDLL('kernel32', use_last_error=True)

            kernel32.GetModuleHandleW.restype = LPVOID
            kernel32.GetModuleHandleW.argtypes = [LPCWSTR]

            stkxModuleHandle = kernel32.GetModuleHandleW('stkx.dll')
            if stkxModuleHandle is None:
                raise STKRuntimeError(f"Error getting stkx.dll module handle ({WinError(get_last_error())})")

            kernel32.GetModuleFileNameA.restype = DWORD
            kernel32.GetModuleFileNameA.argtypes = [LPVOID, c_char_p, DWORD]

            cPath = create_unicode_buffer(1024)
            res = kernel32.GetModuleFileNameW(LPVOID(stkxModuleHandle), cPath, DWORD(1024))
            if res == 0:
                err = get_last_error()
                errormsg = 'Failed to get STKX module file name'
                if err != 0:
                    errormsg += f' ({WinError(err)})'
                raise STKRuntimeError(errormsg)
            stkxdllpath = cPath.value

            jniCoreDllPath = os.path.join(os.path.dirname(stkxdllpath), 'AgJNICore.dll')
            return jniCoreDllPath
    def CreateContainer(self, progid):
        return self.Java_agi_core_awt_AgAwtNativeContainer_CreateContainer_Python(LPVOID(None), LPVOID(None), LPCWSTR(progid))
    def AttachContainer(self, pContainer, winid):
        self.Java_agi_core_awt_AgAwtNativeContainer_AttachContainer(LPVOID(None), LPVOID(None), winid, LPVOID(None), LPVOID(pContainer))
    def ResizeContainer(self, pContainer, x, y, width, height):
        self.Java_agi_core_awt_AgAwtNativeContainer_ResizeContainer(LPVOID(None), LPVOID(None), LPVOID(pContainer), INT(x), INT(y), INT(width), INT(height))
    def Paint(self):
        self.Java_agi_core_awt_AgAwtNativeContainer_Paint(LPVOID(None), LPVOID(None), LPVOID(pContainer))
    def GetIAgUnknown(self, pContainer):
        return self.Java_agi_core_awt_AgAwtNativeContainer_GetIAgUnknown_Python(LPVOID(None), LPVOID(None), LPVOID(pContainer))
    def DetachContainer(self, pContainer):
        self.Java_agi_core_awt_AgAwtNativeContainer_DetachContainer(LPVOID(None), LPVOID(None), LPVOID(pContainer))
    def ReleaseContainer(self, pContainer):
        self.Java_agi_core_awt_AgAwtNativeContainer_ReleaseContainer(LPVOID(None), LPVOID(None), LPVOID(pContainer))
        
class ControlBase(Frame):
    '''
    Base class for Tkinter controls.
    '''
    def __init__(self, parent, *args, **kwargs):
        Frame.__init__(self, parent, *args, **kwargs)
        self._is_container_attached = False
        self._nativeContainerMethods = NativeContainerMethods()
        
        self._container = self._nativeContainerMethods.CreateContainer(self._progid)
        self._unk = self._nativeContainerMethods.GetIAgUnknown(self._container)
        
        _cntrlinit_unk = IUnknown()
        _cntrlinit_unk.p = LPVOID(self._unk)
        
        self._interface._private_init(self, _cntrlinit_unk)
        
        self.bind('<Configure>', self.Resize)
        
    def __setattr__(self, attrname, value):
        try:
            self._interface.__setattr__(self, attrname, value)
        except:
            Frame.__setattr__(self, attrname, value)
        
    def Resize(self, event):
        '''
        Occurs when the frame is resized.
        '''
        if not self._is_container_attached:
            self._nativeContainerMethods.AttachContainer(self._container, self.winfo_id())
            self._is_container_attached = True
        self._nativeContainerMethods.ResizeContainer(self._container, 0, 0, event.width, event.height)
        
    def destroy(self):
        '''
        Occurs before the frame is destroyed.
        '''
        self._nativeContainerMethods.DetachContainer(self._container)
        self._nativeContainerMethods.ReleaseContainer(self._container)
        super().destroy()

class GlobeControl(IAgUiAxVOCntrl, ControlBase):
    '''
    The 3D Globe control for Tkinter.
    '''
    _progid = "STKX12.VOControl.1"
    _interface = IAgUiAxVOCntrl

    def __init__(self, parent, *args, **kwargs):
        ControlBase.__init__(self, parent, *args, **kwargs)
        
    def __setattr__(self, attrname, value):
        ControlBase.__setattr__(self, attrname, value)

class MapControl(IAgUiAx2DCntrl, ControlBase):
    '''
    The 2D Map control for Tkinter.
    '''
    _progid = "STKX12.2DControl.1"
    _interface = IAgUiAx2DCntrl

    def __init__(self, parent, *args, **kwargs):
        ControlBase.__init__(self, parent, *args, **kwargs)
        
    def __setattr__(self, attrname, value):
        ControlBase.__setattr__(self, attrname, value)

class GfxAnalysisControl(IAgUiAxGfxAnalysisCntrl, ControlBase):
    '''
    The Graphics Analysis control for Tkinter.
    '''
    _progid = "STKX12.GfxAnalysisControl.1"
    _interface = IAgUiAxGfxAnalysisCntrl

    def __init__(self, parent, *args, **kwargs):
        ControlBase.__init__(self, parent, *args, **kwargs)
        
    def __setattr__(self, attrname, value):
        ControlBase.__setattr__(self, attrname, value)
